import { NextFunction, Request, Response } from 'express';
import { getCurrentUser } from '../utils/auth.utils';
import UsersService from '../services/users.services';
import { AccessDeniedException } from '../utils/errors.utils';

export default class UsersController {
  static async getAllUsers(_req: Request, res: Response, next: NextFunction) {
    try {
      const users = await UsersService.getAllUsers();

      res.status(200).json(users);
    } catch (error: unknown) {
      next(error);
    }
  }

  static async getSingleUser(req: Request, res: Response, next: NextFunction) {
    try {
      const userId: number = parseInt(req.params.userId);
      const requestedUser = await UsersService.getSingleUser(userId);

      res.status(200).json(requestedUser);
    } catch (error: unknown) {
      next(error);
    }
  }

  static async getUserSettings(req: Request, res: Response, next: NextFunction) {
    try {
      const userId: number = parseInt(req.params.userId);
      const settings = await UsersService.getUserSettings(userId);

      res.status(200).json(settings);
    } catch (error: unknown) {
      next(error);
    }
  }

  static async getUsersFavoriteProjects(req: Request, res: Response, next: NextFunction) {
    try {
      const userId: number = parseInt(req.params.userId);

      const projects = await UsersService.getUsersFavoriteProjects(userId);

      res.status(200).json(projects);
    } catch (error: unknown) {
      next(error);
    }
  }

  static async updateUserSettings(req: Request, res: Response, next: NextFunction) {
    try {
      const { defaultTheme, slackId } = req.body;
      const user = await getCurrentUser(res);

      await UsersService.updateUserSettings(user, defaultTheme, slackId);

      res.status(200).json({ message: `Successfully updated settings for user ${user.userId}.` });
    } catch (error: unknown) {
      next(error);
    }
  }

  static async logUserIn(req: Request, res: Response, next: NextFunction) {
    try {
      const idToken = req.body.id_token;
      const header = req.headers['user-agent'];

      const { user, token } = await UsersService.logUserIn(idToken, header!);

      res.cookie('token', token, { httpOnly: true, sameSite: 'none', secure: true });
      res.status(200).json(user);
    } catch (error: unknown) {
      next(error);
    }
  }

  // for dev login only!
  static async logUserInDev(req: Request, res: Response, next: NextFunction) {
    try {
      if (process.env.NODE_ENV === 'production') throw new AccessDeniedException('Cant dev login on production!');

      const { userId } = req.body;
      const header = req.headers['user-agent'];

      if (!header) {
        throw new AccessDeniedException('You cannot put an unknown for dev login!');
      }

      const user = await UsersService.logUserInDev(userId, header);

      res.status(200).json(user);
    } catch (error: unknown) {
      next(error);
    }
  }

  static async updateUserRole(req: Request, res: Response, next: NextFunction) {
    try {
      const targetUserId: number = parseInt(req.params.userId);
      const { role } = req.body;
      const user = await getCurrentUser(res);

      const targetUser = await UsersService.updateUserRole(targetUserId, user, role);

      res.status(200).json(targetUser);
    } catch (error: unknown) {
      next(error);
    }
  }
}
