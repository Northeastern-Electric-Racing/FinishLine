/*
  Warnings:

  - You are about to drop the column `progress` on the `Work_Package` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Work_Package" DROP COLUMN "progress";
