-- AlterTable
ALTER TABLE "User_Settings" ADD COLUMN     "slackId" TEXT NOT NULL DEFAULT '';
