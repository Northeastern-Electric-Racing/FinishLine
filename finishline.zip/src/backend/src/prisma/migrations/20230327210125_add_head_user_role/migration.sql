-- AlterEnum
ALTER TYPE "Role" ADD VALUE 'HEAD';
