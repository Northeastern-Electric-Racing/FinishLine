# Note

We commandeered this from here: https://github.com/MaTeMaTuK/gantt-task-react

If the code is a mess, that's why

We'll clean it up eventually...
